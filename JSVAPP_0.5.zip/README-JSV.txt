JSVAPP v0.5 – Versión funcional de pruebas

Incluye:
- Módulo de aprobación y envío al cliente
- Registro automático en panel local
- Interfaz HTML lista para web o APK embebido
- Autoejecutable para Windows (autoejecutar.bat)

Para iniciar:
1. Extrae el archivo ZIP
2. Ejecuta 'autoejecutar.bat'
3. Abre el HTML si no se abre automáticamente

Versión sin diseño visual final (pendiente agregar íconos, logos y estilos oficiales)

By: Shelby GT500 para JSV
